﻿//1. feladat
Console.Write("Adja meg a körkúp sugarát: ");
double radius = Convert.ToDouble(Console.ReadLine());

Console.Write("Adja meg a körkúp magasságát: ");
double height = Convert.ToDouble(Console.ReadLine());

double radiusSquared = Math.Pow(radius, 2);
double heightSquared = Math.Pow(height, 2);

Console.WriteLine($"A körkúp térfogata: {(1.0 / 3.0 * Math.PI * radiusSquared * height):N2}.");
Console.WriteLine($"A körkúp térfogata: {(
    (Math.PI * radiusSquared) +
    (Math.PI * radius * Math.Sqrt(radiusSquared + heightSquared))
    ):N2}.");

//2. feladat
Console.Write("Adja meg a sípálya legmeredekebb lejtőjét: ");
uint steapness = Convert.ToUInt32(Console.ReadLine());

Console.BackgroundColor = ConsoleColor.White;
Console.Clear();

if (steapness <= 12)
{
    Console.ForegroundColor = ConsoleColor.Blue;
    Console.WriteLine("A pálya könnyű.");
}
else if (steapness <= 20)
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine("A pálya középnehéz.");
}
else
{
    Console.ForegroundColor = ConsoleColor.Black;
    Console.WriteLine("A pálya nehéz.");
}

Console.BackgroundColor = ConsoleColor.Black;
Console.ForegroundColor = ConsoleColor.White;

//3. feladat
Random random = new Random();

int thrownNumber = random.Next(1, 7);
Console.WriteLine(thrownNumber switch
{
    1 => "1-et dobtál, kimaradsz a dobásból!",
    6 => "Lépj előre 6-ot, és újra dobhatsz!",
    _ => $"Lépj előre {thrownNumber} mezőt!"
});

//4. feladat
double number = random.NextDouble() * 200 - 100;

Console.WriteLine($"A generált szám a {number}");
Console.WriteLine($"A szám {(
    number switch
    {
        < 0 => "negatív",
        0 => "nulla",
        _ => "pozitív"
    })}.");
Console.WriteLine($"Lefele kerekített értéke: {Math.Floor(number)}");
Console.WriteLine($"Matematikai kerekített értéke: {Math.Round(number)}");
Console.WriteLine($"Felfelé kerekített értéke: {Math.Ceiling(number)}");
Console.WriteLine($"A matematikai kerekítés a " +
    $"{(Math.Floor(number) == Math.Round(number) ? "lefele" : "felfele")}" +
    $"kerekített értékkel egyezik meg.");
Console.WriteLine($"A matematikai kerekítés {(Math.Round(number) % 2 == 0 ? "páros" : "páratlan")}.");